"""Organização de alimentadores em zonas, tronco/ramais e blocos por ativo de referência."""
